import {createRouter, createWebHashHistory} from 'vue-router'
import Home from './views/Home'
import Add from './views/Add'
import User from './views/User'
import Record from './views/Record'
import Setting from './views/Setting'
import Comment from './views/Comment'

const routes = [
  {path: '/',component: Home},
  {path: '/add',component: Add},
  {path: '/user',component: User},
  {path: '/record',component: Record,name:'record'},
  {path: '/setting',component: Setting},
  {path: '/comment',component: Comment},
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
