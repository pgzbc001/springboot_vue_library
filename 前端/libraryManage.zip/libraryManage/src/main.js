import { createApp } from 'vue'
import App from './App.vue'
import 'ant-design-vue/dist/antd.css'
import router from './router.js'
const app = createApp(App)
import {
  Comment,
  List,
  Upload,
  Modal,
  Table,
  Layout,
  Form,
  Menu,
  Input,
  Button,
  message } from 'ant-design-vue';

app.use(router)
.use(Comment)
.use(Table)
.use(Layout)
.use(List)
.use(Form)
.use(Menu)
.use(Input)
.use(Button)
.use(Upload)
.use(Modal)

import {
  ProfileOutlined,
  PayCircleOutlined,
  LockOutlined,
  DatabaseOutlined,
  ReadOutlined,
  HomeOutlined,
  SmileOutlined,
  FormOutlined,
  TeamOutlined,
  BarChartOutlined,
  UserOutlined,
  BookOutlined,
  CommentOutlined,
} from '@ant-design/icons-vue';

app.component('LockOutlined',LockOutlined)
.component('DatabaseOutlined',DatabaseOutlined)
.component('PayCircleOutlined',PayCircleOutlined)
.component('ReadOutlined',ReadOutlined)
.component('BookOutlined',BookOutlined)
.component('UserOutlined',UserOutlined)
.component('ProfileOutlined',ProfileOutlined)
.component('BarChartOutlined',BarChartOutlined)
.component('HomeOutlined',HomeOutlined)
.component('SmileOutlined',SmileOutlined)
.component('FormOutlined',FormOutlined)
.component('TeamOutlined',TeamOutlined)
.component('CommentOutlined',CommentOutlined)

app.config.globalProperties.$form = Form
app.config.globalProperties.$message = message;
app.config.globalProperties.$confirm = Modal.confirm;
import http from './libs/http'
http.baseURL = "http://localhost:88";
app.config.globalProperties.$http = http;
import {getTime} from './libs/utils'
app.config.globalProperties.$getTime = getTime;

window.vm=app.mount('#app')
