module.exports = {
  productionSourceMap: false,
  publicPath: './'
}