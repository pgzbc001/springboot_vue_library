 package com.example.demo;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

 public class Test {
    public static void main(String[] args) {
        // int[] arr = {1,2,3,4,5};
        // String[] str = {"tom", "marry"};
        // System.out.println(str[1]);
//        String aa = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
//        System.out.println(Base64.getEncoder().encodeToString((new SimpleDateFormat("yyyy-MM-dd").format(new Date())).getBytes()));
        System.out.println(12313+"ssss");
//        Map success = new HashMap();
//        success.put("aa","aa");

    }
}
